import { userManager } from './authConfig.js';

const AUTO_LOGIN_FLAG = 'auth.autoLoginAttempted';
const SIGNED_OUT_FLAG = 'auth.signedOut';

// Fail-safe sessionStorage access for the SSO guard. If storage is blocked
// (locked-down/private browser), autoLoginTried() reports `true` and
// markAutoLogin() reports failure, so we never fire a prompt=none redirect we
// can't guard — an un-guarded redirect would loop. The app degrades to anon.
function autoLoginTried() {
    try {
        return sessionStorage.getItem(AUTO_LOGIN_FLAG) === 'true';
    } catch {
        return true;
    }
}
function markAutoLogin() {
    try {
        sessionStorage.setItem(AUTO_LOGIN_FLAG, 'true');
        return true;
    } catch {
        return false;
    }
}

const listeners = new Set();
let currentUser = null;
let currentState = 'loading';

// oidc-client-ts network calls (OIDC metadata fetch, token exchange) have no
// timeout. If Zitadel is slow or its discovery endpoint is blocked, initAuth()
// never reaches a terminal state and the auth UI sits on 'loading' forever.
const DEATH_SWITCH_MS = 8000;
const INTERACTIVE_SIGNIN_TIMEOUT_MS = 10 * 60 * 1000;
let deathSwitch = null;
let interactiveSignin = null;

function clearDeathSwitch() {
    if (deathSwitch !== null) {
        clearTimeout(deathSwitch);
        deathSwitch = null;
    }
}

function emit() {
    const payload = { state: currentState, user: currentUser };
    listeners.forEach((cb) => {
        try {
            cb(payload);
        } catch (e) {
            console.error('Auth listener error:', e);
        }
    });
}

function setAuthState(state, user = null) {
    if (state !== 'loading') clearDeathSwitch();
    currentState = state;
    currentUser = user;
    emit();
}

export function onAuthChange(cb) {
    listeners.add(cb);
    cb({ state: currentState, user: currentUser });
    return () => listeners.delete(cb);
}

export function getCurrentUser() {
    return currentUser;
}

export function getAuthState() {
    return currentState;
}

export function isAuthenticated() {
    return currentState === 'authenticated';
}

export async function getAccessToken() {
    const user = await userManager.getUser();
    if (!user || user.expired) return null;
    return user.access_token;
}

function isCallbackUrl() {
    const params = new URLSearchParams(window.location.search);
    return (params.has('code') || params.has('error')) && params.has('state');
}

function cleanUrl() {
    const cleanHref = window.location.origin + window.location.pathname + window.location.hash;
    window.history.replaceState({}, document.title, cleanHref);
}

export async function login() {
    if (interactiveSignin) return interactiveSignin;
    sessionStorage.setItem(AUTO_LOGIN_FLAG, 'true');
    localStorage.removeItem(SIGNED_OUT_FLAG);
    const controller = typeof AbortController === 'undefined' ? null : new AbortController();
    const timeout = controller
        ? setTimeout(
            () => controller.abort('The sign-in window did not finish in time.'),
            INTERACTIVE_SIGNIN_TIMEOUT_MS,
        )
        : null;
    try {
        // Keep the Cesium scene and its exact camera/selection state alive in
        // the opener while Zitadel completes in a separate top-level window.
        const pending = userManager.signinPopup({
            popupAbortOnClose: true,
            popupSignal: controller?.signal,
        });
        interactiveSignin = pending;
        await pending;
    } catch (e) {
        // Never fall back to a full-page redirect: that would destroy the scene
        // state this popup flow exists to preserve.
        console.error('Login window failed:', e);
        setAuthState('unauthenticated', null);
    } finally {
        if (timeout !== null) clearTimeout(timeout);
        interactiveSignin = null;
    }
}

export async function logout() {
    localStorage.setItem(SIGNED_OUT_FLAG, 'true');
    sessionStorage.setItem(AUTO_LOGIN_FLAG, 'true');
    try {
        await userManager.signoutRedirect();
    } catch (e) {
        console.warn('Signout redirect failed, clearing local session:', e);
        try {
            await userManager.removeUser();
        } catch {}
        setAuthState('unauthenticated', null);
    }
}

export async function initAuth() {
    setAuthState('loading');

    // Guarantee the loading state always resolves: if no terminal state is
    // reached within 8 s (a hung metadata fetch or token exchange), release
    // the UI to 'unauthenticated' so the sign-in button appears. A late
    // success still self-corrects via the addUserLoaded listener below.
    clearDeathSwitch();
    deathSwitch = setTimeout(() => {
        deathSwitch = null;
        if (currentState === 'loading') {
            console.warn('Auth init exceeded 8 s — releasing loading state.');
            setAuthState('unauthenticated', null);
        }
    }, DEATH_SWITCH_MS);

    userManager.events.addUserLoaded((u) => setAuthState('authenticated', u));
    userManager.events.addUserUnloaded(() => setAuthState('unauthenticated', null));
    userManager.events.addAccessTokenExpired(async () => {
        try {
            await userManager.removeUser();
        } catch {}
        setAuthState('unauthenticated', null);
    });

    try {
        if (isCallbackUrl()) {
            try {
                const user = await userManager.signinCallback();
                // Popup callbacks only notify the opener; it exchanges the
                // code, stores the user and updates this live scene.
                if (!user) {
                    clearDeathSwitch();
                    return;
                }
                cleanUrl();
                setAuthState('authenticated', user);
            } catch (e) {
                console.error('OIDC callback failed:', e);
                cleanUrl();
                setAuthState('unauthenticated', null);
            }
            return;
        }

        const existing = await userManager.getUser();
        if (existing && !existing.expired) {
            setAuthState('authenticated', existing);
            return;
        }

        if (existing && existing.expired) {
            try {
                await userManager.removeUser();
            } catch {}
        }

        let signedOut = false;
        try {
            signedOut = localStorage.getItem(SIGNED_OUT_FLAG) === 'true';
        } catch {}

        // Cross-app SSO: a top-level prompt=none redirect to Zitadel. First-party
        // to the IdP, so the shared Zitadel session cookie is sent — if the user
        // signed in to any Aireon app, Zitadel bounces back with a code and this
        // app signs in silently; otherwise it returns error=login_required, which
        // the generic callback branch handles on the next load as "stay
        // anonymous". Using
        // prompt=none (not a plain signinRedirect) means an anonymous visitor is
        // never forced onto the Zitadel login page — no UI is rendered, just two
        // fast 3xx hops. Attempted at most once per tab so reloads don't bounce;
        // markAutoLogin() must succeed before we redirect (see the helper).
        if (!autoLoginTried() && !signedOut && markAutoLogin()) {
            try {
                await userManager.signinRedirect({ extraQueryParams: { prompt: 'none' } });
                return;
            } catch (e) {
                console.error('Cross-app SSO redirect failed to start:', e);
            }
        }

        setAuthState('unauthenticated', null);
    } catch (e) {
        console.error('Auth init failed:', e);
        setAuthState('unauthenticated', null);
    }
}
