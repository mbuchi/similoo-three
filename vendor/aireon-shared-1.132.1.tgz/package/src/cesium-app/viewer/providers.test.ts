// Guards the satellite-imagery composition in providers.js.
//
// providers.js is vanilla JS against the CesiumJS global, so the test installs a
// minimal `globalThis.Cesium` stub and imports the module through a non-literal
// specifier (keeps `tsc --noEmit` happy without turning on allowJs).
//
// The regression these tests exist for: SWISSIMAGE must be the imagery that
// covers Switzerland, and it must sit ON TOP of a global underlay rather than
// replacing it, or the globe renders as a white void outside the Swiss extent.

import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';

/* eslint-disable @typescript-eslint/no-explicit-any */

const PROVIDERS_PATH = './providers.js';

let providers: any;

class StubCredit {
    html: string;
    showOnScreen: boolean;
    constructor(html: string, showOnScreen: boolean) {
        this.html = html;
        this.showOnScreen = showOnScreen;
    }
}

function makeCesiumStub() {
    return {
        Credit: StubCredit,
        Rectangle: {
            fromDegrees: (west: number, south: number, east: number, north: number) => ({
                west,
                south,
                east,
                north
            })
        },
        WebMercatorTilingScheme: class {},
        WebMapTileServiceImageryProvider: class {
            kind = 'wmts';
            constructor(options: any) {
                Object.assign(this, options);
            }
        },
        UrlTemplateImageryProvider: class {
            kind = 'urlTemplate';
            constructor(options: any) {
                Object.assign(this, options);
            }
        },
        ArcGisMapServerImageryProvider: {
            fromUrl: async (url: string, options: any) => ({
                kind: 'arcgis',
                url,
                ...options
            })
        }
    };
}

// Minimal stand-in for Cesium's ImageryLayerCollection + Viewer.
function makeViewer(baseLayerProvider: any = { kind: 'stub-base' }) {
    const layers: any[] = [{ provider: baseLayerProvider, show: true }];
    let renderRequests = 0;

    const collection = {
        get length() {
            return layers.length;
        },
        get: (index: number) => layers[index],
        // Mirrors Cesium: addImageryProvider(provider, index) forwards index to
        // add(), which throws when index > length.
        addImageryProvider(provider: any, index?: number) {
            const layer = { provider, show: true };
            if (index === undefined) {
                layers.push(layer);
            } else {
                if (index < 0 || index > layers.length) {
                    throw new Error(`index ${index} out of range (length ${layers.length})`);
                }
                layers.splice(index, 0, layer);
            }
            return layer;
        }
    };

    return {
        imageryLayers: collection,
        scene: {
            requestRender: () => {
                renderRequests += 1;
            }
        },
        isDestroyed: () => false,
        _layers: layers,
        get _renderRequests() {
            return renderRequests;
        }
    };
}

beforeAll(async () => {
    (globalThis as any).Cesium = makeCesiumStub();
    // Non-literal specifier: TypeScript types this `any` instead of demanding a
    // declaration file for the .js module.
    const specifier: string = PROVIDERS_PATH;
    providers = await import(specifier);
});

describe('global underlay', () => {
    it('defaults to NASA GIBS, not Esri', async () => {
        const provider = await providers.createGlobalBaseImageryProvider();
        expect(provider.url).toContain('gibs.earthdata.nasa.gov');
        expect(provider.url).not.toContain('arcgisonline.com');
    });

    it('createImageryProvider (the viewer baseLayer call site) is the same default', async () => {
        const provider = await providers.createImageryProvider();
        expect(provider.url).toContain('gibs.earthdata.nasa.gov');
        expect(provider.url).not.toContain('arcgisonline.com');
    });

    it('requests NASA tiles as {z}/{y}/{x} and stops at the Level8 ceiling', async () => {
        const provider = await providers.createNasaBlueMarbleImageryProvider();
        // WMTS-REST path order is TileMatrix/TileRow/TileCol. Transposing it
        // returns valid-looking tiles of the wrong place.
        expect(provider.url).toContain('/{z}/{y}/{x}.jpeg');
        expect(provider.url).toContain('GoogleMapsCompatible_Level8');
        expect(provider.maximumLevel).toBe(8);
        expect(provider.credit.html).toContain('GIBS');
    });

    it('keeps Esri reachable as an explicit opt-in underlay only', async () => {
        const provider = await providers.createGlobalBaseImageryProvider(
            providers.GLOBAL_BASE_SOURCES.esri
        );
        expect(provider.url).toContain('arcgisonline.com/arcgis/rest/services/World_Imagery');
        expect(providers.DEFAULT_GLOBAL_BASE_SOURCE).toBe(providers.GLOBAL_BASE_SOURCES.nasa);
    });
});

describe('SWISSIMAGE overlay', () => {
    it('uses swisstopo axis order {TileMatrix}/{TileCol}/{TileRow} = z/x/y', async () => {
        const provider = await providers.createSwissImageImageryProvider();
        expect(provider.url).toContain('/3857/{TileMatrix}/{TileCol}/{TileRow}.jpeg');
        expect(provider.url).toContain('ch.swisstopo.swissimage');
        expect(provider.maximumLevel).toBe(20);
        expect(provider.credit.html).toContain('swisstopo');
    });

    it('is clamped to the declared Swiss extent', async () => {
        const provider = await providers.createSwissImageImageryProvider();
        expect(provider.rectangle).toEqual({
            west: providers.SWISS_WMTS_EXTENT_DEGREES.west,
            south: providers.SWISS_WMTS_EXTENT_DEGREES.south,
            east: providers.SWISS_WMTS_EXTENT_DEGREES.east,
            north: providers.SWISS_WMTS_EXTENT_DEGREES.north
        });
    });
});

describe('swisstopo relief shading', () => {
    it('replaces Esri World Hillshade with swissALTI3D, {z}/{x}/{y}, PNG', async () => {
        const provider = await providers.createSwissHillshadeImageryProvider();
        expect(provider.url).toContain('ch.swisstopo.swissalti3d-reliefschattierung');
        expect(provider.url).toContain('/3857/{z}/{x}/{y}.png');
        expect(provider.url).not.toContain('arcgisonline.com');
        // Transposing to {z}/{y}/{x} returns HTTP 400 here rather than a valid
        // tile of the wrong place, but assert the order anyway — the swisstopo
        // vs Esri axis flip is the standing trap in this suite.
        expect(provider.url).not.toContain('/{z}/{y}/{x}');
        expect(provider.credit.html).toContain('swisstopo');
    });

    it('stops at the 3857_18 matrix-set ceiling', async () => {
        const provider = await providers.createSwissHillshadeImageryProvider();
        expect(provider.maximumLevel).toBe(18);
    });

    it('is clamped to the same declared Swiss extent as SWISSIMAGE', async () => {
        const provider = await providers.createSwissHillshadeImageryProvider();
        expect(provider.rectangle).toEqual({
            west: providers.SWISS_WMTS_EXTENT_DEGREES.west,
            south: providers.SWISS_WMTS_EXTENT_DEGREES.south,
            east: providers.SWISS_WMTS_EXTENT_DEGREES.east,
            north: providers.SWISS_WMTS_EXTENT_DEGREES.north
        });
    });

    it('keeps the Esri hillshade reachable for hosts that need global relief', async () => {
        const provider = await providers.createHillshadeImageryProvider();
        expect(provider.url).toContain('World_Hillshade');
    });
});

describe('setupSatelliteImagery', () => {
    it('adds SWISSIMAGE directly above the existing global base', async () => {
        const viewer = makeViewer();
        const group = await providers.setupSatelliteImagery(viewer);

        expect(viewer._layers).toHaveLength(2);
        expect(viewer._layers[0]).toBe(group.globalLayer);
        expect(viewer._layers[1]).toBe(group.swissImageLayer);
        expect(group.swissImageLayer.provider.url).toContain('ch.swisstopo.swissimage');
        // requestRenderMode viewers need a nudge or the layer only shows on the
        // next camera move.
        expect(viewer._renderRequests).toBe(1);
    });

    it('slots in above the underlay even when other basemaps are already stacked', async () => {
        const viewer = makeViewer();
        const alreadyThere = viewer.imageryLayers.addImageryProvider({ kind: 'streets' });
        const group = await providers.setupSatelliteImagery(viewer);

        expect(viewer._layers[0]).toBe(group.globalLayer);
        expect(viewer._layers[1]).toBe(group.swissImageLayer);
        expect(viewer._layers[2]).toBe(alreadyThere);
    });

    it('creates the underlay itself when the viewer has no imagery yet', async () => {
        const viewer = makeViewer();
        viewer._layers.length = 0;
        const group = await providers.setupSatelliteImagery(viewer);

        expect(group.globalLayer.provider.url).toContain('gibs.earthdata.nasa.gov');
        expect(group.swissImageLayer.provider.url).toContain('ch.swisstopo.swissimage');
    });

    it('exposes one .show that drives both layers, so host basemap pickers work unchanged', async () => {
        const viewer = makeViewer();
        const group = await providers.setupSatelliteImagery(viewer);

        expect(group.show).toBe(true);

        group.show = false;
        expect(group.globalLayer.show).toBe(false);
        expect(group.swissImageLayer.show).toBe(false);
        expect(group.show).toBe(false);

        group.show = true;
        expect(group.globalLayer.show).toBe(true);
        expect(group.swissImageLayer.show).toBe(true);
        expect(group.show).toBe(true);
    });

    it('returns null instead of throwing on a destroyed viewer', async () => {
        const viewer = makeViewer();
        viewer.isDestroyed = () => true;
        await expect(providers.setupSatelliteImagery(viewer)).resolves.toBeNull();
    });
});

describe('half-built composition guard', () => {
    // The warning timer is module state, and earlier tests in this file arm it.
    // Disarm it explicitly (that is what setupSatelliteImagery does) so these
    // tests do not depend on describe ordering.
    beforeEach(async () => {
        await providers.setupSatelliteImagery(makeViewer());
    });

    afterEach(() => {
        vi.useRealTimers();
        vi.restoreAllMocks();
    });

    it('warns when the underlay is created but the overlay is never wired', async () => {
        vi.useFakeTimers();
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});

        await providers.createImageryProvider();
        expect(warn).not.toHaveBeenCalled();

        await vi.advanceTimersByTimeAsync(15000);

        expect(warn).toHaveBeenCalledTimes(1);
        expect(warn.mock.calls[0][0]).toContain('SWISSIMAGE');
    });

    it('stays quiet once setupSatelliteImagery has run', async () => {
        vi.useFakeTimers();
        const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});

        const viewer = makeViewer(await providers.createImageryProvider());
        await providers.setupSatelliteImagery(viewer);
        await vi.advanceTimersByTimeAsync(60000);

        expect(warn).not.toHaveBeenCalled();
    });
});

describe('attribution', () => {
    it('credits swisstopo for Switzerland and names the global underlay', () => {
        expect(providers.SATELLITE_IMAGERY_ATTRIBUTION_HTML).toContain('swisstopo');
        expect(providers.SATELLITE_IMAGERY_ATTRIBUTION_HTML).toContain('SWISSIMAGE');
        expect(providers.SATELLITE_IMAGERY_ATTRIBUTION_HTML).toContain('NASA');
        expect(providers.SATELLITE_IMAGERY_ATTRIBUTION_HTML).not.toContain('Esri');
    });
});
