// Cesium provider factories.
//
// Terrain stays on swisstopo's high-resolution Swiss DEM tileset — that's the
// authoritative source for the country and feeds the building footprints +
// the precise sun-on-roof analysis.
//
// Imagery is a TWO-LAYER composition as of v1.120.0:
//
//   layer 0  global underlay   NASA GIBS "Blue Marble: Shaded Relief and
//                              Bathymetry" — keyless, public domain, global.
//   layer 1  swisstopo SWISSIMAGE, rectangle-clamped to Switzerland.
//
// Over Switzerland the user sees the official 10 cm/px federal orthophoto;
// outside it the clamp lets the global underlay show through, so the globe
// never renders as a void. Build the pair with setupSatelliteImagery().
//
// Esri ArcGIS World Imagery is NO LONGER the satellite default.
//
// Relief shading followed in v1.121.0: createSwissHillshadeImageryProvider()
// serves swisstopo's swissALTI3D multidirectional relief, and that is what the
// day-tour should swap to (relief only, no photographic sun shadows, so the
// dynamic shadows we cast read cleanly against neutral ground). Like every
// swisstopo layer here it is Switzerland-only, so a host must leave the global
// underlay visible beneath it — see createSwissHillshadeImageryProvider.
//
// The three remaining ArcGIS layers below (streets / light / dark) are
// deliberately kept: they are global CARTOGRAPHIC reference basemaps, not
// aerial imagery, so the "no Esri imagery" rule does not reach them, and the
// swisstopo alternatives would be Swiss-only. See each factory for the reason.
//
// --- Why SWISSIMAGE cannot simply replace the base layer -------------------
//
//   1. Coverage stops. The layer declares 5.140242,45.398181 → 11.47757,48.230651
//      and, past a filler apron, wmts.geo.admin.ch answers **HTTP 400** — not a
//      transparent tile. An unbounded provider therefore spends a failed request
//      on every off-extent tile instead of quietly showing nothing, so every
//      swisstopo provider here is `rectangle`-clamped.
//   2. This viewer is Swiss in purpose but global in reach: the default camera
//      (8.67/46.72 @ 4500 m, pitch −20°) always has France/Italy/Germany/Austria
//      on the horizon, and Settings → Display offers two deliberately GLOBAL
//      presets (`osm` = Cesium OSM Buildings on Cesium World Terrain, `google` =
//      Google Photorealistic 3D Tiles). With a Swiss-only base and nothing under
//      it those views render as a white void (scene.backgroundColor is WHITE).
//   3. So SWISSIMAGE is composited as an OVERLAY on top of a global base layer,
//      never as the base itself: imageryLayers[0] stays global and the
//      SWISSIMAGE layer sits above it.
//
// --- Picking the global underlay: what was evaluated (2026-07-28) ----------
//
// All four candidates were probed live from this machine; the numbers below are
// measured, not quoted from docs.
//
//   * Cesium Ion World Imagery (asset 2, Bing Aerial) — REJECTED, unavailable.
//     It needs Cesium.Ion.defaultAccessToken. hood's production bundle carries
//     no VITE_CESIUM_ION_TOKEN (no JWT anywhere in assets/main-*.js, and the
//     "token is not configured" i18n strings ship), and the token CesiumJS
//     1.105.1 bakes in as its own default is dead:
//         GET api.cesium.com/v1/assets/2/endpoint?access_token=<cesium default>
//         -> HTTP 401 {"code":"INVALID_TOKEN"}
//     The same 401 is why hood's "3D OSM + Cesium terrain" preset is disabled.
//
//   * EOX Sentinel-2 cloudless (tiles.maps.eox.at) — REJECTED on license.
//     Technically excellent: HTTP 200 to z16, CORS echoes our origin,
//     `cache-control: max-age=604800`. But the free grant is CC BY-NC-SA 4.0;
//     commercial products need a paid "EOX Commercial Attribution-RestrictedUse
//     1.2" license. Aireon is commercial, so this is not ours to use for free.
//
//   * NASA GIBS Blue Marble Shaded Relief + Bathymetry — CHOSEN.
//     Keyless, US-Government public domain, `access-control-allow-origin: *`,
//     `cache-control: max-age=259200`, cloud-free and seasonally stable.
//     Its ceiling is the real trade-off: the GoogleMapsCompatible_Level8 matrix
//     set stops at z8 (~500 m/px) and z9 returns HTTP 400, hence
//     NASA_GIBS_MAX_LEVEL. Cesium upsamples past that rather than erroring, so
//     flying to a foreign city shows soft imagery where Esri used to be sharp.
//     That is acceptable: hood's content (SwissTLM3D buildings, swisstopo
//     terrain, Swiss parcels, sun-on-roof analysis) exists only inside
//     Switzerland, where SWISSIMAGE covers the underlay completely. Off-CH
//     imagery is horizon backdrop, and at the ~100 km horizon distance of the
//     default camera a z8 tile is indistinguishable from a z19 one.
//
//   * Esri ArcGIS World Imagery — kept, but only as an opt-in alternative
//     underlay (createEsriWorldImageryProvider / GLOBAL_BASE_SOURCES.esri).
//     It is global and sharp to z19 with no key, so if the soft off-CH backdrop
//     is ever judged a regression, pass { globalBase: 'esri' } — but it is not
//     the default, and it is never what covers Switzerland.

const ARCGIS_IMAGERY_URL =
    'https://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer';

const ARCGIS_HILLSHADE_URL =
    'https://services.arcgisonline.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer';

// swisstopo swissALTI3D multidirectional relief — the Swiss replacement for
// Esri World Hillshade. Same WMTS service and the same {z}/{x}/{y} axis order as
// every other geo.admin layer here, but PNG, and its matrix set is `3857_18`.
const SWISS_HILLSHADE_URL =
    'https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.swissalti3d-reliefschattierung/default/current/3857/{z}/{x}/{y}.png';

// The matrix set is named 3857_18 and means it: z19 answers HTTP 400 (measured
// 2026-07-28 at 19/274581/183595, over Zurich). Cesium upsamples level 18 past
// that instead of firing a failing request per tile.
const SWISS_HILLSHADE_MAX_LEVEL = 18;

const ARCGIS_STREETS_URL =
    'https://services.arcgisonline.com/arcgis/rest/services/World_Street_Map/MapServer';

const ARCGIS_LIGHT_URL =
    'https://services.arcgisonline.com/arcgis/rest/services/Canvas/World_Light_Gray_Base/MapServer';

const ARCGIS_DARK_URL =
    'https://services.arcgisonline.com/arcgis/rest/services/Canvas/World_Dark_Gray_Base/MapServer';

// NASA GIBS "Blue Marble: Shaded Relief and Bathymetry" — the global underlay
// that shows through wherever SWISSIMAGE is clamped away. WMTS-REST, so the
// path order is {TileMatrix}/{TileRow}/{TileCol} = {z}/{y}/{x}, NOT {z}/{x}/{y}
// like swisstopo. GoogleMapsCompatible_Level8 is a plain XYZ Web Mercator
// pyramid (one 256 px tile at level 0), which is Cesium's default tiling scheme.
const NASA_GIBS_BLUE_MARBLE_URL =
    'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/BlueMarble_ShadedRelief_Bathymetry/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpeg';

// The matrix set is named Level8 and means it: z9 answers HTTP 400. Declaring
// the ceiling makes Cesium upsample the level-8 tile instead of firing a failing
// request per tile, exactly like the rectangle clamp on the swisstopo layers.
const NASA_GIBS_MAX_LEVEL = 8;

export async function createTerrainProvider() {
    return await Cesium.CesiumTerrainProvider.fromUrl(
        'https://3d.geo.admin.ch/ch.swisstopo.terrain.3d/v1/',
        {
            credit: new Cesium.Credit(
                '<a href="https://www.swisstopo.ch/" target="_blank">&copy; swisstopo</a> ',
                true
            )
        }
    );
}

// Cesium World Terrain (Ion asset id 1). Requires a valid
// Cesium.Ion.defaultAccessToken. Paired with the OSM Buildings preset so the
// global tileset has matching global terrain.
export async function createCesiumWorldTerrainProvider() {
    return await Cesium.createWorldTerrainAsync();
}

// Google Photorealistic 3D Tiles — global photogrammetric mesh that includes
// its own terrain and imagery. Requires a Google Maps Platform "Map Tiles
// API" key in VITE_GOOGLE_MAPS_API_KEY. When this preset is active the
// imagery globe + the Swiss / OSM building tilesets are hidden, since the
// Google tiles already cover everything.
export async function createGooglePhotorealisticTileset() {
    const key = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
    if (!key) {
        throw new Error('VITE_GOOGLE_MAPS_API_KEY is not set');
    }
    return await Cesium.Cesium3DTileset.fromUrl(
        `https://tile.googleapis.com/v1/3dtiles/root.json?key=${encodeURIComponent(key)}`,
        { showCreditsOnScreen: true }
    );
}

// Which global layer sits UNDERNEATH the SWISSIMAGE overlay. See the "Picking
// the global underlay" section in the header for the measured comparison.
export const GLOBAL_BASE_SOURCES = Object.freeze({
    nasa: 'nasa',
    esri: 'esri'
});

export const DEFAULT_GLOBAL_BASE_SOURCE = GLOBAL_BASE_SOURCES.nasa;

// Esri ArcGIS World Imagery. Until v1.120.0 this was hood's satellite basemap;
// it is now only an OPT-IN alternative for the global underlay, and it never
// covers Switzerland (SWISSIMAGE is composited over it). Global, keyless,
// sharp to ~z19.
export async function createEsriWorldImageryProvider() {
    return await Cesium.ArcGisMapServerImageryProvider.fromUrl(ARCGIS_IMAGERY_URL, {
        enablePickFeatures: false
    });
}

// NASA GIBS Blue Marble — the default global underlay. Coarse (z8 / ~500 m/px)
// but keyless, public domain and worldwide, so the globe renders everywhere.
export async function createNasaBlueMarbleImageryProvider() {
    return new Cesium.UrlTemplateImageryProvider({
        url: NASA_GIBS_BLUE_MARBLE_URL,
        minimumLevel: 0,
        maximumLevel: NASA_GIBS_MAX_LEVEL,
        credit: nasaGibsCredit()
    });
}

// The global underlay, i.e. what belongs in `new Cesium.Viewer({ baseLayer })`.
//
// ⚠ On its own this is NOT the satellite basemap — it is only the bottom half
// of it. Pair it with setupSatelliteImagery(viewer), which puts SWISSIMAGE on
// top; a viewer that boots with this layer alone shows a soft 500 m/px world
// over Switzerland too.
export async function createGlobalBaseImageryProvider(
    source = DEFAULT_GLOBAL_BASE_SOURCE
) {
    return source === GLOBAL_BASE_SOURCES.esri
        ? await createEsriWorldImageryProvider()
        : await createNasaBlueMarbleImageryProvider();
}

// Half-built compositions are the failure mode this whole change can produce:
// an app that repins @aireon/shared and keeps its old
// `baseLayer: createImageryProvider()` line, but never calls
// setupSatelliteImagery(), gets a globe with no SWISSIMAGE on it — Switzerland
// rendering at ~500 m/px. That looks like a blurry map, not like a wiring bug,
// so it can ship unnoticed. Say it out loud in the console instead.
let compositionWarningTimer = null;

function armCompositionWarning() {
    if (compositionWarningTimer !== null || typeof setTimeout !== 'function') return;
    compositionWarningTimer = setTimeout(() => {
        compositionWarningTimer = null;
        console.warn(
            '[aireon/cesium-app] createImageryProvider() returned the GLOBAL UNDERLAY ' +
                'only, and nothing called setupSatelliteImagery(viewer) afterwards. ' +
                'swisstopo SWISSIMAGE is therefore NOT on the globe and Switzerland is ' +
                'rendering at roughly 500 m/px. See cesium-app/viewer/providers.js.'
        );
    }, COMPOSITION_WARNING_DELAY_MS);
    // Node/vitest only: never hold the process open for a diagnostic.
    compositionWarningTimer?.unref?.();
}

function disarmCompositionWarning() {
    if (compositionWarningTimer === null) return;
    clearTimeout(compositionWarningTimer);
    compositionWarningTimer = null;
}

// Long enough that a slow boot (terrain + tileset + auth) never trips it.
const COMPOSITION_WARNING_DELAY_MS = 15000;

// Back-compat name for the `baseLayer` call site. Same contract as
// createGlobalBaseImageryProvider(): the UNDERLAY, not the satellite basemap.
export async function createImageryProvider(source = DEFAULT_GLOBAL_BASE_SOURCE) {
    armCompositionWarning();
    return await createGlobalBaseImageryProvider(source);
}

// Esri World Hillshade. Superseded as the relief basemap by
// createSwissHillshadeImageryProvider(); kept exported only as the global
// fallback for a host that needs relief outside Switzerland, and still the one
// place in this module where Esri is a *terrain* rather than a cartographic
// source. New call sites should use the swisstopo one.
export async function createHillshadeImageryProvider() {
    return await Cesium.ArcGisMapServerImageryProvider.fromUrl(ARCGIS_HILLSHADE_URL, {
        enablePickFeatures: false
    });
}

// ArcGIS World Street Map — a global CARTOGRAPHIC street map, not aerial
// imagery, so the suite's "satellite imagery must be swisstopo" rule does not
// apply. The swisstopo equivalent would be pixelkarte-farbe, which this module
// already exposes separately as createSwissTopoImageryProvider() and which hosts
// already offer as its own basemap entry; swapping this one for it would ship
// the same map twice and delete the only global street reference the picker has.
export async function createStreetsImageryProvider() {
    return await Cesium.ArcGisMapServerImageryProvider.fromUrl(ARCGIS_STREETS_URL, {
        enablePickFeatures: false
    });
}

// ArcGIS Light Gray Canvas — a muted global reference basemap (the neutral
// backdrop you pick when the DATA on top is the subject), again cartography
// rather than imagery. swisstopo publishes a gray pixelkarte-grau, but it is
// Switzerland-only and there is no dark counterpart, so converting this one
// alone would split the light/dark pair across two different cartographies.
export async function createLightImageryProvider() {
    return await Cesium.ArcGisMapServerImageryProvider.fromUrl(ARCGIS_LIGHT_URL, {
        enablePickFeatures: false
    });
}

// ArcGIS Dark Gray Canvas — same reasoning as the light canvas above, and
// swisstopo publishes no dark basemap at all.
export async function createDarkImageryProvider() {
    return await Cesium.ArcGisMapServerImageryProvider.fromUrl(ARCGIS_DARK_URL, {
        enablePickFeatures: false
    });
}

// Shared extent + attribution for every wmts.geo.admin.ch layer below.
//
// This is the ows:WGS84BoundingBox both layers declare in
// https://wmts.geo.admin.ch/EPSG/3857/1.0.0/WMTSCapabilities.xml — i.e. the
// extent of the actual Swiss data.
//
// Measured against the live service (2026-07-28), both layers are more generous
// than they advertise: each keeps answering out to roughly 3.7–14.2°E /
// 44.3–48.5°N and only returns HTTP 400 beyond that. What comes back in that
// apron differs, and neither case is worth requesting:
//   - pixelkarte-farbe returns a blank white ~700-byte tile, so clamping costs
//     nothing at all and simply stops the pointless requests;
//   - swissimage returns real but 5 m SPOT-5 satellite imagery from 2004/2005,
//     which in a composition where a global base shows through would mean
//     covering better, newer imagery with worse, older imagery.
// The apron is also undocumented and can be withdrawn without notice, whereas
// the declared box is the published contract. Clamping only ever
// under-requests, so it can never produce a 400.
export const SWISS_WMTS_EXTENT_DEGREES = Object.freeze({
    west: 5.140242,
    south: 45.398181,
    east: 11.47757,
    north: 48.230651
});

function swissWmtsRectangle() {
    const { west, south, east, north } = SWISS_WMTS_EXTENT_DEGREES;
    return Cesium.Rectangle.fromDegrees(west, south, east, north);
}

function swisstopoCredit() {
    return new Cesium.Credit(
        '<a href="https://www.swisstopo.ch/" target="_blank">&copy; swisstopo</a>',
        true
    );
}

// NASA asks that GIBS imagery be credited; the data itself is public domain.
function nasaGibsCredit() {
    return new Cesium.Credit(
        '<a href="https://earthdata.nasa.gov/gibs" target="_blank">NASA EOSDIS GIBS</a>',
        true
    );
}

// One-line attribution for an app's About / Info dialog. The suite rule is that
// basemap credit lives there rather than painted on the map, and this spells out
// the split so the swisstopo provenance is explicit rather than implied by a
// logo. Cesium also renders both layers' Credit objects in its own credit
// container, which is what satisfies swisstopo's attribution requirement.
export const SATELLITE_IMAGERY_ATTRIBUTION_HTML =
    'Satellite imagery: <a href="https://www.swisstopo.ch/" target="_blank">&copy; swisstopo</a> ' +
    'SWISSIMAGE over Switzerland, ' +
    '<a href="https://earthdata.nasa.gov/gibs" target="_blank">NASA EOSDIS GIBS</a> ' +
    'Blue Marble elsewhere.';

// swisstopo SWISSIMAGE — the official Swiss orthophoto mosaic, and the intended
// replacement for Esri World Imagery inside Switzerland.
//
// WMTS over Web Mercator (EPSG:3857). The service's `3857_20` tile matrix set is
// a plain XYZ pyramid (level 0 = one 256 px tile at the world's top-left corner),
// which is exactly Cesium's default WebMercatorTilingScheme — so {TileMatrix} is
// the numeric zoom level and {TileCol}/{TileRow} are x/y. Levels run 0–20
// (~10 cm/px at level 20 in Switzerland); level 21 is refused with HTTP 400,
// hence maximumLevel.
//
// Near the border the mosaic blends into 5 m SPOT-5 satellite imagery from
// 2004/2005 rather than current aerial photography — coarser than the Swiss
// interior, but not blank. See SWISS_WMTS_EXTENT_DEGREES for why the clamp cuts
// that filler off at the declared Swiss extent.
//
// READ THE HEADER before wiring this up: it is an OVERLAY over a global base
// layer, not a base layer on its own. setupSatelliteImagery() below does that
// wiring — prefer it over calling this directly.
export async function createSwissImageImageryProvider() {
    return new Cesium.WebMapTileServiceImageryProvider({
        url: 'https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.swissimage/default/current/3857/{TileMatrix}/{TileCol}/{TileRow}.jpeg',
        layer: 'ch.swisstopo.swissimage',
        style: 'default',
        format: 'image/jpeg',
        tileMatrixSetID: '3857_20',
        tilingScheme: new Cesium.WebMercatorTilingScheme(),
        maximumLevel: 20,
        rectangle: swissWmtsRectangle(),
        credit: swisstopoCredit()
    });
}

// swisstopo "pixelkarte-farbe" — the authoritative Swiss topographic map.
// WMTS, Web Mercator (EPSG:3857), tiled at zoom 0–19 (matrix set `3857_19`).
// Anonymous access is OK for non-commercial / interactive use per swisstopo's
// terms; the credit banner Cesium renders satisfies the attribution requirement.
//
// Same coverage rectangle as SWISSIMAGE — see SWISS_WMTS_EXTENT_DEGREES for why
// the clamp matters.
export async function createSwissTopoImageryProvider() {
    return new Cesium.UrlTemplateImageryProvider({
        url: 'https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-farbe/default/current/3857/{z}/{x}/{y}.jpeg',
        minimumLevel: 0,
        maximumLevel: 19,
        rectangle: swissWmtsRectangle(),
        credit: swisstopoCredit()
    });
}

// swisstopo swissALTI3D multidirectional relief — the Swiss replacement for
// Esri World Hillshade, and what a sun-path / shadow analysis wants underneath
// it: pure relief shading with no photographic sun in it, so the shadows the
// scene casts are the only shadows on screen. swisstopo builds it from six
// combined sun positions (mean azimuth NW), which reads flatter and less
// directional than a single-sun hillshade.
//
// Measured against the live service 2026-07-28: z18 200 (31 KB PNG), z19 400,
// off-extent 400, `access-control-allow-origin: *`,
// `cache-control: public, max-age=3600, s-maxage=31556952`. Tiles are fully
// opaque (alpha 255 everywhere), so this HIDES whatever is under it.
//
// ⚠ Switzerland-only, same rectangle as SWISSIMAGE. A host that flips its
// basemap by hiding every other layer will therefore blank the rest of the
// globe when this is selected — keep the global underlay (index 0) visible
// beneath it, exactly as setupSatelliteImagery() does for SWISSIMAGE.
export async function createSwissHillshadeImageryProvider() {
    return new Cesium.UrlTemplateImageryProvider({
        url: SWISS_HILLSHADE_URL,
        minimumLevel: 0,
        maximumLevel: SWISS_HILLSHADE_MAX_LEVEL,
        rectangle: swissWmtsRectangle(),
        credit: swisstopoCredit()
    });
}

// The satellite basemap is two Cesium imagery layers, but every basemap picker
// in the suite treats a basemap as one thing it can flip `.show` on. This handle
// is that one thing: assigning `.show` fans out to both layers, so a host's
// existing `layer.show = (key === id)` state machine keeps working unchanged.
class SatelliteImageryGroup {
    constructor(globalLayer, swissImageLayer) {
        this.globalLayer = globalLayer;
        this.swissImageLayer = swissImageLayer;
        this.layers = [globalLayer, swissImageLayer].filter(Boolean);
    }

    get show() {
        // The global underlay is the authoritative one — SWISSIMAGE can only
        // ever be a clamped patch on top of it.
        return this.globalLayer ? this.globalLayer.show : false;
    }

    set show(value) {
        const next = !!value;
        this.layers.forEach((layer) => {
            layer.show = next;
        });
    }
}

/**
 * Compose the suite's satellite basemap on a viewer: swisstopo SWISSIMAGE
 * clamped to Switzerland, sitting on top of a global underlay.
 *
 * The underlay is normally the layer the viewer was constructed with
 * (`baseLayer: Cesium.ImageryLayer.fromProviderAsync(await createImageryProvider())`),
 * so this only has to add the SWISSIMAGE layer above it. If the viewer has no
 * imagery layers yet, the underlay is created here too.
 *
 * SWISSIMAGE is added immediately after the underlay, before any lazily-created
 * alternative basemaps, so a later `addImageryProvider()` stacks on top of it
 * rather than being buried by it.
 *
 * @param {Cesium.Viewer} viewer
 * @param {{ globalBase?: 'nasa'|'esri' }} [options]
 * @returns {Promise<SatelliteImageryGroup|null>} handle with a `.show` setter
 *   that drives both layers, or null if the viewer is gone.
 */
export async function setupSatelliteImagery(viewer, options = {}) {
    if (!viewer || viewer.isDestroyed?.()) return null;

    disarmCompositionWarning();

    const collection = viewer.imageryLayers;
    const globalBase = options.globalBase ?? DEFAULT_GLOBAL_BASE_SOURCE;

    let globalLayer = collection.length > 0 ? collection.get(0) : null;
    if (!globalLayer) {
        const provider = await createGlobalBaseImageryProvider(globalBase);
        globalLayer = collection.addImageryProvider(provider);
    }

    const swissImageProvider = await createSwissImageImageryProvider();

    // Re-check: awaiting the provider gives the host time to tear the viewer
    // down (route change, HMR), and addImageryProvider on a destroyed viewer
    // throws.
    if (viewer.isDestroyed?.()) return null;

    // Index 1 = directly above the underlay at index 0. Explicit, because a
    // plain append would bury SWISSIMAGE under any alternative basemap layer a
    // host had already added.
    const swissImageLayer = collection.addImageryProvider(swissImageProvider, 1);

    // hood boots in requestRenderMode (renderMode.js), so without this the new
    // layer only appears on the next camera move.
    viewer.scene?.requestRender?.();

    return new SatelliteImageryGroup(globalLayer, swissImageLayer);
}

export function getCesiumTileset() {
    return Cesium.Cesium3DTileset.fromUrl(
        'https://vectortiles.geo.admin.ch/3d-tiles/ch.swisstopo.swisstlm3d.3d/20201020/tileset.json'
    );
}
