# @aireon/shared

Shared design system, app shell, account menu, map UI, auth helpers, PRM helpers, Claire, telemetry, error reporting, and typed RES API utilities for the Aireon app suite.

This repository is the canonical implementation of the Aireon design guide. New apps should adopt these primitives instead of copying UI code from an existing app.

## Documentation Index

| Guide | Use it for |
|---|---|
| [Docs index](docs/README.md) | Full documentation map for this repo. |
| [Adoption guide](docs/ADOPTION_GUIDE.md) | Build a fresh Aireon app with the shared design system. |
| [Feature recipes](docs/FEATURE_RECIPES.md) | Navbar, account menu, save image, PRM, Claire, Liquid Glass, release notes, telemetry. |
| [API surface](docs/API_SURFACE.md) | Export map: which component/helper lives where and when to import subpaths. |
| [Source map and organization review](docs/SOURCE_MAP.md) | How the code is organized and what is already documented in source. |
| [New app checklist](docs/NEW_APP_CHECKLIST.md) | Checklist for a new app or AI agent implementation. |
| [Navbar standard](docs/NAVBAR_STANDARD.md) | Required navbar components, CSS tokens, icon behavior, and exceptions. |
| [Map-first standard](docs/MAP_FIRST_STANDARD.md) | Reference architecture for map-first apps. |
| [Mobile UX standard](docs/MOBILE_STANDARD.md) | Mobile sheet, touch target, safe area, and content density rules. |
| [Navbar compliance report](docs/NAVBAR_COMPLIANCE_REPORT_2026-06-17.md) | Current app compliance and accepted exceptions. |

## Organization Review

The code is organized well for reuse:

- `src/index.ts` is a clear public barrel, with comments separating brand, release notes, i18n, PRM, auth, app access, Claire, telemetry, error logging, profile, API, theme, map, navigation, table, and screenshot exports.
- Heavy or server-safe surfaces have subpath entries in `package.json` and `tsup.config.ts`: `/api`, `/signal-collect`, `/errorlog-collect`, `/gemini`, `/geoadmin`, `/map-defaults`, `/map-interaction`, `/map-style`, `/basemap`, `/comparables`, `/claire`, and `/table`.
- UI domains are separated by folder: `brand`, `nav`, `map`, `prm`, `glass`, `claire`, `errorlog`, `theme`, `profile`, `table`, `skeleton`, and `screenshot`.
- The most important primitives have useful inline JSDoc and intent comments, especially `AppNavbar`, `MapToolbar`, `MapUserMenu`, `GlassProvider`, `screenshotNodeFilter`, `createSignalClient`, `createErrorLogger`, `createResApiClient`, and the theme store.
- Existing standards documents already cover navbar, map-first composition, mobile UX, and compliance. The new docs in this PR make the root README a professional entry point and add adoption recipes for engineers and AI agents.

Main gap fixed here: the previous README still described an early package with release notes and RES client examples only. It did not explain the current design-system surface, shared app shell, user menu, PRM, save-image, Liquid Glass, Claire, or how a new app should adopt the package.

## Reference App Audit

The documentation was checked against current `valoo`, `roofs`, and `sitepool` implementations on 2026-06-27:

- `valoo` remains the canonical full parcel-map pattern: `AppNavbar`, shared geo.admin search, `OpenWithMenu`, `NavIconButton` actions for Search history and About, `MapToolbar` for Save image and My images, Liquid Glass in Settings, and lower-frequency tools in `MapUserMenu.toolbarItems`.
- `roofs` confirms the same shell works for heavier 3D parcel maps: a high desktop z-index keeps the account dropdown above the side panel, shared basemaps and panel primitives stay in use, and Claire is mounted only when parcel context exists.
- `sitepool` confirms the standard for candidate-style apps that are not simple parcel valuation maps: keep `AppNavbar`, `MapUserMenu`, `ParcelPanelShell`, PRM helpers, Claire, screenshot filtering, access gates, About attribution, and shared basemap/glass CSS, but let app-specific panels and massing controls own their domain logic.

The practical standard is: use shared chrome first, then add app-specific map/domain controls in the slots the shared shell already provides. Do not fork navbar, account, profile, PRM, release notes, bug report, search history, screenshot filtering, or Claire UI.

## Install

Apps consume this package directly from GitHub, pinned to a tag:

```json
{
  "dependencies": {
    "@aireon/shared": "github:mbuchi/aireon-shared#v1.67.0"
  }
}
```

Then run:

```bash
npm install
```

The built `dist/` is committed, so consuming apps do not build this package during install.

When bumping an existing app, force the GitHub dependency lockfile to refresh:

```bash
rm -rf node_modules/@aireon/shared
npm install @aireon/shared@github:mbuchi/aireon-shared#vX.Y.Z
```

Verify `package-lock.json` points at the intended commit, not just the intended tag text in `package.json`.

## Required CSS

Most app-shell and map UI components depend on shared CSS:

```ts
import '@aireon/shared/map-ui.css';
import '@aireon/shared/scrollbars.css';
import '@aireon/shared/glass.css';
```

Map apps that use shared basemaps also import:

```ts
import '@aireon/shared/basemap.css';
```

If the app uses Tailwind and scans compiled dependencies, include:

```js
content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}',
  './node_modules/@aireon/shared/dist/**/*.js',
],
```

The self-contained navbar and map UI CSS lives in `@aireon/shared/map-ui.css`, so consuming apps should not fork navbar button, wordmark, account menu, or top map-control styling.

## First App Shell

Minimal map-first shell:

```tsx
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import {
  AuthProvider,
  GlassProvider,
  initTheme,
} from '@aireon/shared';
import '@aireon/shared/map-ui.css';
import '@aireon/shared/glass.css';
import '@aireon/shared/scrollbars.css';
import './index.css';
import App from './App';

initTheme('light');

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider silentSso={false}>
      <GlassProvider>
        <App />
      </GlassProvider>
    </AuthProvider>
  </StrictMode>,
);
```

Use [Adoption guide](docs/ADOPTION_GUIDE.md) and [New app checklist](docs/NEW_APP_CHECKLIST.md) for the full setup.

## Core Design Rules

- App ids are lowercase everywhere: repo, domain, telemetry `appName`, Hub catalog id, PRM/image source, and browser title prefix.
- Browser titles use `appname - Subtitle` with an ASCII hyphen.
- Use `AireonHubLink` and `AireonAppWordmark`; do not hand-roll the Hub mark or red `oo` wordmark.
- Use `AppNavbar` for the top bar and `MapToolbar` for the canonical icon order of controls that remain in the navbar.
- Use `MapUserMenu` for sign-in, profile, saved parcels, search history, release notes, tours, About, Share, Locate, Theme, and bug report entry points when those actions are better as lower-frequency tools.
- Use `GlassProvider` plus `buildGlassSettingsItem` for Liquid Glass settings.
- Use `screenshotNodeFilter` and `data-screenshot-ignore` for save-image exports.
- Use `SavedParcelsModal` and PRM API helpers for saved parcels.
- Use `AppAccessGate` or the shared access decision helpers for private, beta, admin, premium, or under-construction apps.
- Use `Skeleton`, not spinners, for fixed layout loading states.
- Use `DataTable` for ordinary sortable/filterable tables.
- Use `createSignalClient` and `createErrorLogger` with lowercase app names.

## Public Import Map

Most React app code imports from the package root:

```ts
import {
  AppNavbar,
  MapToolbar,
  MapUserMenu,
  NavIconButton,
  OpenWithMenu,
  AireonHubLink,
  AireonAppWordmark,
  AuthProvider,
  AppAccessGate,
  GlassProvider,
  buildGlassSettingsItem,
  AboutModal,
  SavedParcelsModal,
  ClaireAssistant,
  ReleaseNotesPanel,
  Skeleton,
  DataTable,
  createSignalClient,
  createErrorLogger,
  screenshotNodeFilter,
} from '@aireon/shared';
```

Use subpaths when you need a smaller or server-safe graph:

```ts
import { createResApiClient } from '@aireon/shared/api';
import { signalCollectHandler } from '@aireon/shared/signal-collect';
import { errorLogCollectHandler } from '@aireon/shared/errorlog-collect';
import { fetchGeminiWithFallback } from '@aireon/shared/gemini';
import { searchGeoAdminAddresses } from '@aireon/shared/geoadmin';
import { DEFAULT_MAP_ZOOM } from '@aireon/shared/map-defaults';
import { isParcelInteractive } from '@aireon/shared/map-interaction';
import { BasemapPicker } from '@aireon/shared/basemap';
import { ClaireAssistant } from '@aireon/shared/claire';
import { DataTable } from '@aireon/shared/table';
```

See [API surface](docs/API_SURFACE.md) for the full source map.

### About dialog

Use `AboutModal` for every app's About entry. It provides the suite-standard
responsive dialog, accessible focus handling, data/technology credits, and a
prominent link back to the Aireon application catalog. The catalog action is
always present; multilingual apps should pass localized `aboutLabel`,
`creditsLabel`, and `hubLabel` strings.

## Developing This Package

```bash
npm install
npm run typecheck
npm run lint
npm run test
npm run build
```

`npm run build` uses `tsup` and rewrites `dist/`. Commit `dist/` after source changes that affect exported runtime code. Documentation-only changes do not need a package version bump, tag, or `dist/` rebuild.

## Publishing Runtime Changes

For changes consumed by apps:

1. Update source and tests.
2. Bump `package.json` and `package-lock.json`.
3. Run `npm run typecheck`, `npm run lint`, `npm run test`, and `npm run build`.
4. Commit source, docs if relevant, package metadata, and rebuilt `dist/`.
5. Merge the PR.
6. Create and push the matching Git tag, for example `v1.68.0`.
7. Bump consumers with `npm install @aireon/shared@github:mbuchi/aireon-shared#v1.68.0`.

Do not assume a shared package change reaches apps until the tag exists and each consumer lockfile resolves to the new commit.
