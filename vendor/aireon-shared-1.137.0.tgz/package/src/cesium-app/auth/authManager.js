import { userManager } from './authConfig.js';
import { clearSsoHint, setSsoHint } from './ssoHint.js';

// The automatic cross-app SSO bounce is REMOVED (product decision 2026-08-08):
// an unauthenticated visitor must never be auto-redirected to Zitadel — the
// loginV2 UI ignores `prompt=none`, so a probe without a live IdP session
// strands the visitor on the login page. initAuth() now settles straight to
// 'unauthenticated' when no local session exists; sign-in is always
// user-initiated via login(). The `aireon_sso_hint` cookie is still SET on
// sign-in and CLEARED on sign-out (see ssoHint.js) to protect sibling apps on
// pre-v1.137.0 pins, whose bounce is still gated on it.

const listeners = new Set();
let currentUser = null;
let currentState = 'loading';

// oidc-client-ts network calls (OIDC metadata fetch, token exchange) have no
// timeout. If Zitadel is slow or its discovery endpoint is blocked, initAuth()
// never reaches a terminal state and the auth UI sits on 'loading' forever.
const DEATH_SWITCH_MS = 8000;
const INTERACTIVE_SIGNIN_TIMEOUT_MS = 10 * 60 * 1000;
let deathSwitch = null;
let interactiveSignin = null;

function clearDeathSwitch() {
    if (deathSwitch !== null) {
        clearTimeout(deathSwitch);
        deathSwitch = null;
    }
}

function emit() {
    const payload = { state: currentState, user: currentUser };
    listeners.forEach((cb) => {
        try {
            cb(payload);
        } catch (e) {
            console.error('Auth listener error:', e);
        }
    });
}

function setAuthState(state, user = null) {
    if (state !== 'loading') clearDeathSwitch();
    currentState = state;
    currentUser = user;
    emit();
}

export function onAuthChange(cb) {
    listeners.add(cb);
    cb({ state: currentState, user: currentUser });
    return () => listeners.delete(cb);
}

export function getCurrentUser() {
    return currentUser;
}

export function getAuthState() {
    return currentState;
}

export function isAuthenticated() {
    return currentState === 'authenticated';
}

export async function getAccessToken() {
    const user = await userManager.getUser();
    if (!user || user.expired) return null;
    return user.access_token;
}

function isCallbackUrl() {
    const params = new URLSearchParams(window.location.search);
    return (params.has('code') || params.has('error')) && params.has('state');
}

function cleanUrl() {
    const cleanHref = window.location.origin + window.location.pathname + window.location.hash;
    window.history.replaceState({}, document.title, cleanHref);
}

export async function login() {
    if (interactiveSignin) return interactiveSignin;
    const controller = typeof AbortController === 'undefined' ? null : new AbortController();
    const timeout = controller
        ? setTimeout(
            () => controller.abort('The sign-in window did not finish in time.'),
            INTERACTIVE_SIGNIN_TIMEOUT_MS,
        )
        : null;
    try {
        // Keep the Cesium scene and its exact camera/selection state alive in
        // the opener while Zitadel completes in a separate top-level window.
        const pending = userManager.signinPopup({
            popupAbortOnClose: true,
            popupSignal: controller?.signal,
        });
        interactiveSignin = pending;
        await pending;
    } catch (e) {
        // Never fall back to a full-page redirect: that would destroy the scene
        // state this popup flow exists to preserve.
        console.error('Login window failed:', e);
        setAuthState('unauthenticated', null);
    } finally {
        if (timeout !== null) clearTimeout(timeout);
        interactiveSignin = null;
    }
}

export async function logout() {
    // Explicit sign-out ends the Zitadel session. Clearing the cross-app hint
    // protects sibling apps still on pre-v1.137.0 pins, whose auto-SSO bounce
    // is gated on it (AuthProvider parity).
    clearSsoHint();
    try {
        await userManager.signoutRedirect();
    } catch (e) {
        console.warn('Signout redirect failed, clearing local session:', e);
        try {
            await userManager.removeUser();
        } catch {}
        setAuthState('unauthenticated', null);
    }
}

export async function initAuth() {
    setAuthState('loading');

    // Guarantee the loading state always resolves: if no terminal state is
    // reached within 8 s (a hung metadata fetch or token exchange), release
    // the UI to 'unauthenticated' so the sign-in button appears. A late
    // success still self-corrects via the addUserLoaded listener below.
    clearDeathSwitch();
    deathSwitch = setTimeout(() => {
        deathSwitch = null;
        if (currentState === 'loading') {
            console.warn('Auth init exceeded 8 s — releasing loading state.');
            setAuthState('unauthenticated', null);
        }
    }, DEATH_SWITCH_MS);

    userManager.events.addUserLoaded((u) => {
        setAuthState('authenticated', u);
        // Refresh the cross-app hint on every sign-in so sibling apps (React
        // AuthProvider stack included) keep auto-SSO-ing while this browser is
        // actively signed in. Parity with AuthProvider's userLoaded handler.
        setSsoHint();
    });
    userManager.events.addUserUnloaded(() => setAuthState('unauthenticated', null));
    userManager.events.addAccessTokenExpired(async () => {
        try {
            await userManager.removeUser();
        } catch {}
        setAuthState('unauthenticated', null);
    });

    try {
        if (isCallbackUrl()) {
            try {
                const user = await userManager.signinCallback();
                // Popup callbacks only notify the opener; it exchanges the
                // code, stores the user and updates this live scene.
                if (!user) {
                    clearDeathSwitch();
                    return;
                }
                cleanUrl();
                setAuthState('authenticated', user);
            } catch (e) {
                // login_required is the normal "no Zitadel session" answer to a
                // prompt=none probe, not an error — and it proves the hint
                // cookie is stale, so drop it and stop every sibling app from
                // probing a session that no longer exists (AuthProvider parity).
                if (e && e.error === 'login_required') {
                    clearSsoHint();
                } else {
                    console.error('OIDC callback failed:', e);
                }
                cleanUrl();
                setAuthState('unauthenticated', null);
            }
            return;
        }

        const existing = await userManager.getUser();
        if (existing && !existing.expired) {
            setAuthState('authenticated', existing);
            return;
        }

        if (existing && existing.expired) {
            try {
                await userManager.removeUser();
            } catch {}
        }

        // No local session: settle anonymous, with zero redirects. The
        // automatic cross-app SSO bounce that used to live here is REMOVED
        // (product decision 2026-08-08, parity with src/auth/AuthProvider.tsx):
        // an unauthenticated visitor must never be auto-redirected to Zitadel.
        setAuthState('unauthenticated', null);
    } catch (e) {
        console.error('Auth init failed:', e);
        setAuthState('unauthenticated', null);
    }
}
