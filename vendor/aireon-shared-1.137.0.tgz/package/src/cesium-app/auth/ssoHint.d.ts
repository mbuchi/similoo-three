export function setSsoHint(): void;
export function clearSsoHint(): void;
export function hasSsoHint(cookieString?: string): boolean;
