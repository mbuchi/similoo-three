import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import * as ssoHint from './ssoHint.js';

const { hasSsoHint } = ssoHint;

/**
 * Guards for the no-auto-redirect auth standard.
 *
 * The standard was revised 2026-08-08 (product decision): an unauthenticated
 * visitor must NEVER be auto-redirected to Zitadel. The Zitadel loginV2 UI
 * ignores `prompt=none`, so any automatic top-level authorize redirect risks
 * stranding a visitor without a live IdP session on the login page — which
 * reads as the app forcing sign-up on a public surface. Sign-in is always
 * user-initiated (popup); the only allowed full-page navigation to the IdP
 * domain is the explicit `logout()` signout redirect.
 *
 * The `aireon_sso_hint` cookie protocol stays live (set on sign-in, cleared on
 * sign-out) purely to protect apps pinned to older shared versions, whose
 * auto-SSO bounce is still gated on it.
 */
describe('no-auto-redirect auth contract', () => {
  it('reads the cross-app hint out of a cookie jar', () => {
    expect(hasSsoHint('aireon_sso_hint=1')).toBe(true);
    expect(hasSsoHint('theme=dark; aireon_sso_hint=1; other=x')).toBe(true);
    // Absent, cleared, or merely similar names must all read as "no hint".
    expect(hasSsoHint('')).toBe(false);
    expect(hasSsoHint('theme=dark')).toBe(false);
    expect(hasSsoHint('aireon_sso_hint=0')).toBe(false);
    expect(hasSsoHint('not_aireon_sso_hint=1')).toBe(false);
  });

  it('fails closed when no jar is readable', () => {
    // In this node test environment there is no `document` at all — the
    // default-argument path must swallow the ReferenceError and answer false
    // (a browser that can't read cookies can't have completed SSO either).
    expect(hasSsoHint()).toBe(false);
  });

  it('exports no auto-login decision anymore', () => {
    // shouldAttemptAutoLogin was the pure gate for the removed bounce. Its
    // reappearance would mean someone is wiring automatic SSO back up.
    expect('shouldAttemptAutoLogin' in ssoHint).toBe(false);
  });

  it('neither auth stack fires an automatic signin redirect', () => {
    // Source contract over both auth stacks: `signinRedirect(` must not appear
    // at all. Interactive sign-in is `signinPopup` (app state preserved) and
    // the only IdP navigation left is the explicit `signoutRedirect` on
    // logout. A new `signinRedirect(` call — however it is gated — would
    // reintroduce the auto-redirect this standard forbids.
    for (const source of [
      join(__dirname, 'authManager.js'),
      join(__dirname, '..', '..', 'auth', 'AuthProvider.tsx'),
    ]) {
      expect(readFileSync(source, 'utf8')).not.toMatch(/\.signinRedirect\(/);
    }
  });
});
