// Cross-app SSO hint for the LEGACY (imperative cesium-app) auth stack.
//
// Lockstep mirror of the cookie protocol in src/auth/userManager.ts
// (SSO_HINT_COOKIE and friends) — keep the two in sync, the same way
// src/access/decideAppAccess.ts mirrors project_RES/lib/accessPolicy.js. It is
// duplicated as plain JS on purpose: everything under src/cesium-app ships as
// raw source to consumers (`files` + the `./cesium-app/*` export), so importing
// the TypeScript React module from here would break any consumer that doesn't
// compile TS out of node_modules.
//
// The cookie means "this browser recently completed a sign-in to some Aireon
// app". Since v1.137.0 NOTHING in this package bounces on it anymore: the
// automatic cross-app SSO redirect is removed everywhere (product decision
// 2026-08-08 — an unauthenticated visitor must never be auto-redirected to
// Zitadel, whose loginV2 UI ignores `prompt=none` and would strand them on the
// login page). Setting the cookie on sign-in and clearing it on sign-out is
// RETAINED: apps pinned to older shared versions still gate their bounce on
// it, so keeping the protocol live protects their users during the fleet
// transition (clearing on sign-out stops them probing a dead session).

const SSO_HINT_COOKIE = 'aireon_sso_hint';
const SSO_HINT_MAX_AGE = 14 * 24 * 60 * 60;

/** `.aireon.ch` on the canonical suite domain, else null (host-only cookie). */
function ssoHintDomain() {
    try {
        const h = window.location.hostname;
        if (h === 'aireon.ch' || h.endsWith('.aireon.ch')) return '.aireon.ch';
        return null;
    } catch {
        return null;
    }
}

function writeSsoHint(maxAge) {
    try {
        const parts = [`${SSO_HINT_COOKIE}=1`, 'Path=/', `Max-Age=${maxAge}`, 'SameSite=Lax'];
        const domain = ssoHintDomain();
        if (domain) parts.push(`Domain=${domain}`);
        if (window.location.protocol === 'https:') parts.push('Secure');
        document.cookie = parts.join('; ');
    } catch {
        /* cookies blocked — cross-app SSO simply won't propagate */
    }
}

/** Record "this browser is signed in to an Aireon app" for every sibling app. */
export function setSsoHint() {
    writeSsoHint(SSO_HINT_MAX_AGE);
}

/** Drop the hint (sign-out, or a probe proved the Zitadel session is gone). */
export function clearSsoHint() {
    writeSsoHint(0);
}

/**
 * True when some Aireon app signed in from this browser recently. Fails
 * closed (no bounce) when cookies are unreadable: a browser that can't read
 * cookies couldn't have completed the SSO round-trip anyway.
 * @param {string} [cookieString] injected for tests; defaults to document.cookie.
 */
export function hasSsoHint(cookieString) {
    try {
        const jar = cookieString !== undefined ? cookieString : document.cookie;
        return new RegExp('(?:^|; )' + SSO_HINT_COOKIE + '=1').test(jar);
    } catch {
        return false;
    }
}
